<?php
/**
 * RSS layout shell
 */
echo $vars['content'];