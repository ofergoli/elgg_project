<?php
echo 'Test action output';