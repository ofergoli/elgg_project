<?php

/**
 * Factory uncallable exception
 *
 * @access private
 *
 * @package Elgg.Core
 */
class Elgg_Di_FactoryUncallableException extends Exception {}
