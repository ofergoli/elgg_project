Contributor Guides
##################

Participate in making Elgg even better.

Elgg is a community-driven project.
It relies on the support of volunteers to succeed.
Here are some ways you can help:

.. toctree::
   :maxdepth: 1
   
   i18n
   issues
   code
   docs
   money
   releases
   
