Getting Started
###############

Discover if Elgg is right for your community.

.. toctree::
   :maxdepth: 1
  
   features
   license
   install
   development
