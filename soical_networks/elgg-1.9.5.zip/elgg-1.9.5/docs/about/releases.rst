:orphan:

Release Policy
##############

This page has moved.

:doc:`/appendix/releases`
