Plugin Tutorials
################

Walk through all the required steps in order to create your own plugins.

The instructions are detailed enough that you don't need much previous experience on plugin development.

.. toctree::
   :maxdepth: 1
   
   hello_world
   indexpage
   blog
   wysiwyg
   widget