History
#######

The name comes from `a town in Switzerland`__. It also means "elk" or "moose" in Danish.

__ http://www.elgg.ch/de/

Elgg's initial funding was by a company called Curverider Ltd, which was started by David Tosh and Ben Werdmuller.
In 2010, Curverider was acquired by Thematic Networks and control of the open-source project was turned over to `The Elgg Foundation`_.
Today, Elgg is a community-driven open source project and has a variety of contributors and supporters.

.. _The Elgg Foundation: http://theelggfoundation.org
