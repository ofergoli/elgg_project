Developer Guides
################

Customize Elgg's behavior with plugins.

.. toctree::
   :maxdepth: 1
   
   plugins
   actions
   database
   i18n
   events-list
   hooks-list
   menus
   notifications
   river
   routing
   widgets
   views
   themes
   javascript
   web-services
   upgrading
