Administrator Guides
####################

Best practices for effectively managing an Elgg-based site.

.. toctree::
	:maxdepth: 1

	getting_started
	upgrading
	plugins
	performance
	cron