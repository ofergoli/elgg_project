Plugin Skeleton
=========================
This directory includes a plugin skeleton to be used as the starting point when
creating a new plugin. Just create a new directory in /mod/ and copy the files
and directories into it. Then update the manifest and start coding.