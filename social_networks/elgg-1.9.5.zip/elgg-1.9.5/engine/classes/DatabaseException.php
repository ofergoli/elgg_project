<?php
/**
 * Database Exception
 *
 * A generic parent class for database exceptions
 *
 * @package    Elgg.Core
 * @subpackage Exceptions.Stub
 */
class DatabaseException extends Exception {}
