<?php
/**
 * Class Exception
 *
 * A generic parent class for Class exceptions
 *
 * @package    Elgg.Core
 * @subpackage Exceptions.Stub
 */
class ClassException extends Exception {}
