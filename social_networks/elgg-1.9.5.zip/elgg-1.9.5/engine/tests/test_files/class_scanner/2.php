<?php

interface I2_20130207 {

}

class C2_20130207 {

}

trait T2_20130207 {

}
